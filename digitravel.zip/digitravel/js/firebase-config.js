/**
 * DIGITRAVEL FIREBASE CONFIGURATION ARCHITECTURE
 * Serves as a graceful fallback when offline/unconfigured while enabling instant live binding.
 */
const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "digitravel-app.firebaseapp.com",
  projectId: "digitravel-app",
  storageBucket: "digitravel-app.appspot.com",
  messagingSenderId: "00000000000",
  appId: "1:00000000000:web:000000000000"
};

let db = null;
let auth = null;
let isFirebaseInitialized = false;

function initFirebase() {
  if (typeof firebase !== 'undefined') {
    try {
      firebase.initializeApp(firebaseConfig);
      db = firebase.firestore();
      auth = firebase.auth();
      isFirebaseInitialized = true;
      console.log("⚡ Firebase successfully initialized.");
    } catch (e) {
      console.warn("⚠️ Firebase configuration pending. Operating in pure client mode.");
    }
  } else {
    console.info("ℹ️ Running in pure static mode for GitHub Pages.");
  }
}

window.addEventListener('DOMContentLoaded', initFirebase);