/**
 * DIGITRAVEL CORE APP CONTROLLER
 */
let APP_CONFIG = null;
let TRAVEL_DATA = null;

async function loadApplicationData() {
  try {
    const [configRes, travelRes] = await Promise.all([
      fetch('json/config.json'),
      fetch('json/destinations.json')
    ]);
    
    APP_CONFIG = await configRes.json();
    TRAVEL_DATA = await travelRes.json();

    initApp();
  } catch (err) {
    console.error("Initialization error, utilizing embedded fallback dataset.", err);
    useFallbackData();
  }
}

function initApp() {
  setupFloatingAI();
  renderStatesGrid();
  renderFeaturedDestinations(TRAVEL_DATA.featuredDestinations);
  renderCompareBookingTabs();
}

function setupFloatingAI() {
  if (!APP_CONFIG || !APP_CONFIG.aiAssistant) return;
  const { whatsappNumber, whatsappWelcomeMsg, telegramUsername } = APP_CONFIG.aiAssistant;

  const waBtn = document.getElementById('ai-wa-btn');
  const tgBtn = document.getElementById('ai-tg-btn');

  if (waBtn) waBtn.href = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(whatsappWelcomeMsg)}`;
  if (tgBtn) tgBtn.href = `https://t.me/${telegramUsername}`;
}

function navigatePage(pageId) {
  document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active'));
  document.querySelectorAll('.nav-link, .bnav-item').forEach(btn => btn.classList.remove('active'));

  const target = document.getElementById(`page-${pageId}`);
  if (target) {
    target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  document.querySelectorAll(`[data-page="${pageId}"]`).forEach(b => b.classList.add('active'));
}

function toggleDarkMode() {
  document.body.classList.toggle('dark');
}

function renderStatesGrid() {
  const container = document.getElementById('states-grid');
  if (!container || !TRAVEL_DATA) return;

  container.innerHTML = TRAVEL_DATA.states.map(st => `
    <div class="card">
      <span class="badge">${st.id}</span>
      <h3 style="margin:8px 0 4px">${st.name}</h3>
      <p style="font-size:12px; color:var(--text-muted); margin-bottom:8px">Capital: ${st.capital}</p>
      <p style="font-size:13px; margin-bottom:12px"><strong>Top Sights:</strong> ${st.attractions}</p>
      <button class="btn-primary" style="padding:6px 12px; font-size:12px;" onclick="searchDestination('${st.name}')">Explore State</button>
    </div>
  `).join('');
}

function renderFeaturedDestinations(list) {
  const container = document.getElementById('destinations-grid');
  if (!container) return;

  container.innerHTML = list.map(d => `
    <div class="card">
      <img src="${d.heroImg}" class="card-img-top" alt="${d.name}" loading="lazy"/>
      <span class="badge">${d.category}</span>
      <h3 style="margin:8px 0">${d.name}</h3>
      <p style="font-size:13px; color:var(--text-muted); margin-bottom:10px">State: ${d.state} | Best: ${d.bestTime}</p>
      <p style="font-size:13px; margin-bottom:14px">${d.checkpoints}</p>
      <button class="btn-primary" style="width:100%" onclick="openDestinationDetail('${d.id}')">View Complete Guide & Maps</button>
    </div>
  `).join('');
}

function openDestinationDetail(destId) {
  const dest = TRAVEL_DATA.featuredDestinations.find(d => d.id === destId);
  if (!dest) return;

  navigatePage('destination-detail');
  const view = document.getElementById('page-destination-detail');

  view.innerHTML = `
    <div class="container">
      <div style="position:relative; height:320px; border-radius:20px; overflow:hidden; margin-bottom:24px;">
        <img src="${dest.heroImg}" style="width:100%; height:100%; object-fit:cover;" alt="${dest.name}"/>
        <div style="position:absolute; inset:0; background:linear-gradient(to top, rgba(0,0,0,0.8), transparent); display:flex; align-items:flex-end; padding:30px;">
          <div style="color:#FFF">
            <span class="badge" style="background:var(--primary); color:#FFF">${dest.category}</span>
            <h1 style="font-size:36px; font-weight:900; margin-top:6px">${dest.name}</h1>
            <p style="font-size:14px; opacity:0.9">${dest.state} &bull; Ideal Duration: ${dest.idealDuration}</p>
          </div>
        </div>
      </div>

      <div class="grid-3" style="margin-bottom:24px;">
        <div class="card">
          <h4>🛣️ Highway Route</h4>
          <p style="font-size:13px; color:var(--text-muted); margin-top:6px">${dest.checkpoints}</p>
          <div style="margin-top:10px; font-size:13px;">
            <strong>Distance:</strong> ${dest.distanceFromBLR}<br/>
            <strong>Est. Drive Time:</strong> ${dest.driveTime}
          </div>
        </div>
        <div class="card">
          <h4>💰 Daily Budget Guide</h4>
          <p style="font-size:20px; font-weight:800; color:var(--secondary); margin-top:6px">${dest.budgetPerDay}</p>
          <p style="font-size:12px; color:var(--text-muted)">Covers stay, local transport, and meals.</p>
        </div>
        <div class="card">
          <h4>🍽️ Major Highway Food Stops</h4>
          <ul style="padding-left:18px; font-size:13px; margin-top:6px">
            ${dest.foodStops.map(f => `<li>${f}</li>`).join('')}
          </ul>
        </div>
      </div>

      <div class="card" style="margin-bottom:24px;">
        <h3>🗺️ Interactive Route Preview</h3>
        <iframe class="responsive-iframe" src="https://maps.google.com/maps?q=${encodeURIComponent(dest.name)}&t=&z=10&ie=UTF8&iwloc=&output=embed"></iframe>
      </div>

      <div class="card">
        <h3>❓ Travel FAQs & Local Tips</h3>
        <div style="margin-top:14px">
          ${dest.faqs.map(f => `
            <div style="margin-bottom:12px; border-bottom:1px solid var(--border); padding-bottom:8px">
              <strong style="color:var(--primary)">Q: ${f.q}</strong>
              <p style="font-size:13px; margin-top:4px">${f.a}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

function renderCompareBookingTabs() {
  const wrap = document.getElementById('compare-links-output');
  if (!wrap || !APP_CONFIG) return;

  const { flights, trains, buses, hotels } = APP_CONFIG.affiliatePlatforms;

  wrap.innerHTML = `
    <div class="card">
      <h3 style="margin-bottom:12px">✈️ Flight Comparison Portals</h3>
      <div style="display:flex; gap:10px; flex-wrap:wrap">
        ${flights.map(f => `<a href="${f.url}" target="_blank" class="btn-secondary" style="font-size:12px">${f.name} <span class="badge">${f.badge}</span></a>`).join('')}
      </div>

      <h3 style="margin:20px 0 12px">🚆 Railway Booking & Information</h3>
      <div style="display:flex; gap:10px; flex-wrap:wrap">
        ${trains.map(t => `<a href="${t.url}" target="_blank" class="btn-secondary" style="font-size:12px">${t.name} <span class="badge">${t.badge}</span></a>`).join('')}
      </div>

      <h3 style="margin:20px 0 12px">🚌 State & Private Bus Operators</h3>
      <div style="display:flex; gap:10px; flex-wrap:wrap">
        ${buses.map(b => `<a href="${b.url}" target="_blank" class="btn-secondary" style="font-size:12px">${b.name} <span class="badge">${b.badge}</span></a>`).join('')}
      </div>

      <h3 style="margin:20px 0 12px">🏨 Hotel & Stay Booking</h3>
      <div style="display:flex; gap:10px; flex-wrap:wrap">
        ${hotels.map(h => `<a href="${h.url}" target="_blank" class="btn-secondary" style="font-size:12px">${h.name} <span class="badge">${h.badge}</span></a>`).join('')}
      </div>
    </div>
  `;
}

function searchDestination(term) {
  navigatePage('home');
  const input = document.getElementById('home-search');
  if (input) input.value = term;
  
  const filtered = TRAVEL_DATA.featuredDestinations.filter(d => 
    d.name.toLowerCase().includes(term.toLowerCase()) || 
    d.state.toLowerCase().includes(term.toLowerCase())
  );
  renderFeaturedDestinations(filtered);
}

function useFallbackData() {
  APP_CONFIG = {
    aiAssistant: { whatsappNumber: "+919000000000", whatsappWelcomeMsg: "Hello DigiTravel AI!", telegramUsername: "DigiTravelBot" },
    affiliatePlatforms: { flights: [], trains: [], buses: [], hotels: [] }
  };
  TRAVEL_DATA = { states: [], featuredDestinations: [], bengaluruDayTrips: [] };
  initApp();
}

window.addEventListener('DOMContentLoaded', loadApplicationData);