/**
 * EXPENSE MANAGER & BUDGET CALCULATOR ENGINE
 */

function calculateBudget() {
  const transport = parseFloat(document.getElementById('calc-transport').value) || 0;
  const stay = parseFloat(document.getElementById('calc-stay').value) || 0;
  const food = parseFloat(document.getElementById('calc-food').value) || 0;
  const fuel = parseFloat(document.getElementById('calc-fuel').value) || 0;
  const entry = parseFloat(document.getElementById('calc-entry').value) || 0;
  const travelers = parseInt(document.getElementById('calc-travelers').value, 10) || 1;

  const total = transport + stay + food + fuel + entry;
  const perPerson = total / travelers;

  document.getElementById('calc-total').innerText = `₹${total.toLocaleString('en-IN')}`;
  document.getElementById('calc-per-person').innerText = `₹${Math.round(perPerson).toLocaleString('en-IN')}`;
}

function computeGroupExpenses() {
  const fuel = parseFloat(document.getElementById('exp-fuel').value) || 0;
  const stay = parseFloat(document.getElementById('exp-stay').value) || 0;
  const food = parseFloat(document.getElementById('exp-food').value) || 0;
  const misc = parseFloat(document.getElementById('exp-misc').value) || 0;
  const members = parseInt(document.getElementById('exp-members').value, 10) || 1;

  const grandTotal = fuel + stay + food + misc;
  const share = grandTotal / members;

  const summaryEl = document.getElementById('expense-summary-output');
  summaryEl.style.display = 'block';
  summaryEl.innerHTML = `
    <div style="background: var(--glass); border:1px solid var(--primary); padding:20px; border-radius:12px;">
      <h4>💰 Group Expense Summary</h4>
      <p style="margin-top:8px"><strong>Total Cost:</strong> ₹${grandTotal.toLocaleString('en-IN')}</p>
      <p><strong>Split (${members} members):</strong> ₹${Math.round(share).toLocaleString('en-IN')} / person</p>
      <div style="display:flex; gap:10px; margin-top:14px;">
        <button class="btn-primary" style="padding:6px 12px; font-size:12px" onclick="exportExpenseWhatsApp(${grandTotal}, ${share}, ${members})">📲 Share to WhatsApp</button>
        <button class="btn-secondary" style="padding:6px 12px; font-size:12px" onclick="window.print()">🖨️ Print PDF</button>
      </div>
    </div>
  `;
}

function exportExpenseWhatsApp(total, share, members) {
  const text = `*DigiTravel Group Expense Summary*%0A%0A*Total Cost:* ₹${total}%0A*Total Members:* ${members}%0A*Cost Per Person:* ₹${Math.round(share)}%0A%0APlanned with DigiTravel - Explore India. Plan Better.`;
  window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
}